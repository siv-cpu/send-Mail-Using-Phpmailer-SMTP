<!DOCTYPE html> 
<html > 
    <head> 
      
        <title>Localhost email sender & using email library... </title> 
    </head>
    <body autocomplete="off"> 
        <?php
        echo $this->session->flashdata('email_sent');
        echo form_open('/Email_controller/send_mail');
        ?> 

        <input type = "email" name = "email" required placeholder="enter email" /> 
        <br>
        <input type = "text" name = "body" required placeholder="enter message" /> 
        <input type = "submit" value = "SEND MAIL"> 

        <?php
        echo form_close();
        ?> 
    </body>
</html>