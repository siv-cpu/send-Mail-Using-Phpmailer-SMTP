<?php
use PHPMailer\PHPMailer\PHPMailer;

class Email_controller extends CI_Controller {

    function __construct() {
        parent::__construct();
      
        $this->load->helper('form');
    }

    public function index() {

        $this->load->view('contact_form');
    }

    public function send_mail() {
      
      

        require "vendor\phpmailer\phpmailer\src\Exception.php";
        require "vendor\phpmailer\phpmailer\src\PHPMailer.php";
        require "vendor\phpmailer\phpmailer\src\SMTP.php";

        $from_email = "ajsiva088@gmail.com";
     $to_email = $this->input->post('email');
     $name = $this->input->post('name');
     $subject = $this->input->post('subject');
     $body = $this->input->post('message');
    //  $message="hii there";
    $mailer = new PHPMailer(true);

        try{
        $mailer->isSMTP();
				$mailer->Host="smtp.gmail.com";
				$mailer->SMTPAuth =true;
				$mailer->Username="ajsiva088@gmail.com";
				$mailer->Password="rtglucgzrvfzqhzr";
				$mailer->SMTPSecure="ssl";
				$mailer->Port="465";
				$mailer->setFrom($from_email);
				$mailer->addAddress($to_email);
                $mailer->Subject= $subject;
				$mailer->isHTML(true);
                 
                $mailer->Body=$body;
				$mailer->send();
				echo "Mail has been sent";
        }catch(Exception $e){
            echo "Mail Error:".$mailer->ErrorInfo;
        }
        
    }
 
}
 
 
 
 
        //     $from_email = "ajsiva088@gmail.com";
    //     $to_email = $this->input->post('email');

    //     //Load email library 
    //     $this->load->library('email',  $config);

    //     $this->email->from($from_email);
    //     $this->email->to($to_email);
    //     $this->email->subject('Email Test');
    //     $this->email->message('Testing the email class.');

    //     //Send mail 
    //     if ($this->email->send())
    //         $this->session->set_flashdata("email_sent", "Email sent successfully.");
    //     else
    //         $this->session->set_flashdata("email_sent", "Error in sending Email.");
    //     $this->load->view('email_form');
    // }




// rtglucgzrvfzqhzr


?>
